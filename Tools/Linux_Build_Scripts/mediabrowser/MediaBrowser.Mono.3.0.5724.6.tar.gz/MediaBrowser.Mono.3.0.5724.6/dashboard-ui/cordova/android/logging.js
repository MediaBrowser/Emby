﻿window.Logger = {

    log: function (str) {
        LoggingBridge.log(str);
    }
};