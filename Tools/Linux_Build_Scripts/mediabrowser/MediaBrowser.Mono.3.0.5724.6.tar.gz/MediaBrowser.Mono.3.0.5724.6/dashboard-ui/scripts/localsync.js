﻿(function () {

    window.LocalSync = {

        isSupported: function () {
            return false;
        },

        startSync: function () {

        },

        getSyncStatus: function () {
            return 'Idle';
        }
    };

})();